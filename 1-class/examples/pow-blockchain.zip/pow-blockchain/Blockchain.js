const crypto = require("crypto");
const { v4: uuidv4 } = require("uuid");

/**
 * Block represents a block in the blockchain. It has the
 * following params:
 * @index represents its position in the blockchain
 * @timestamp shows when it was created
 * @transactions represents the data about transactions
 * added to the chain
 * @hash represents the hash of the previous block
 */
class Block {
  constructor(index, transactions, prevHash, nonce, hash) {
    this.index = index;
    this.timestamp = Math.floor(Date.now() / 1000);
    this.transactions = transactions;
    this.prevHash = prevHash;
    this.hash = hash;
    this.nonce = nonce;
  }
}

/**
 * A blockchain transaction. Has an amount, sender, and a
 * recipient (not UTXO).
 */
class Transaction {
  constructor(amount, sender, recipient) {
    this.amount = amount;
    this.sender = sender;
    this.recipient = recipient;
    this.tx_id = uuidv4().split("-").join("");
  }
}

/**
 * Blockchain represents the entire blockchain with the
 * ability to create transactions, mine, and validate
 * all blocks.
 */
class Blockchain {
  constructor() {
    this.chain = [this.createGenesisBlock()];
    this.pendingTransactions = [];
    this.difficulty = 2; // Starting difficulty
    this.blockTime = 30000; // Desired time per block in milliseconds (e.g., 30 seconds)
  }

  createGenesisBlock() {
    return new Block(0, [], "0", 0, this.getHash("0", [], 0));
  }

  /**
   * Creates a transaction on the blockchain.
   */
  createTransaction(amount, sender, recipient) {
    this.pendingTransactions.push(new Transaction(amount, sender, recipient));
  }

  /**
   * Add a block to the blockchain.
   */
  addBlock(nonce) {
    const index = this.chain.length;
    const prevHash = this.chain.length !== 0 ? this.chain[this.chain.length - 1].hash : "0";
    const hash = this.getHash(prevHash, this.pendingTransactions, nonce);
    const block = new Block(index, this.pendingTransactions, prevHash, nonce, hash);

    // Reset pending transactions
    this.pendingTransactions = [];
    this.chain.push(block);

    // Adjust difficulty
    this.adjustDifficulty();
  }

  /**
   * Gets the hash of a block.
   */
  getHash(prevHash, txs, nonce) {
    let encrypt = prevHash + nonce;
    txs.forEach((tx) => {
      encrypt += tx.tx_id;
    });
    const hash = crypto
      .createHmac("sha256", "secret")
      .update(encrypt)
      .digest("hex");
    return hash;
  }

  /**
   * Find nonce that satisfies our proof of work.
   */
  proofOfWork(prevHash, txs) {
    let nonce = 0;
    let hash;
    const startTime = Date.now();
    do {
      nonce++;
      hash = this.getHash(prevHash, txs, nonce);
    } while (
      hash.substring(0, this.difficulty) !== Array(this.difficulty + 1).join("0")
    );
    const endTime = Date.now();
    const timeTaken = (endTime - startTime) / 1000; // Time taken in seconds
    const hashRate = nonce / timeTaken; // Hash rate in hashes per second
    console.log(`Hash rate for block ${this.chain.length}: ${hashRate.toFixed(2)} hashes/second`);
    return nonce;
  }

  /**
   * Mine a block and add it to the chain.
   */
  mine() {
    const prevHash = this.chain.length !== 0 ? this.chain[this.chain.length - 1].hash : "0";
    const nonce = this.proofOfWork(prevHash, this.pendingTransactions);
    this.addBlock(nonce);
  }

  /**
   * Check if the chain is valid by going through all blocks and comparing their stored
   * hash with the computed hash.
   */
  chainIsValid() {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const prevBlock = this.chain[i - 1];

      if (
        currentBlock.hash !==
        this.getHash(
          currentBlock.prevHash,
          currentBlock.transactions,
          currentBlock.nonce
        )
      ) {
        return false;
      }

      if (currentBlock.prevHash !== prevBlock.hash) {
        return false;
      }
    }
    return true;
  }

  adjustDifficulty() {
    const latestBlock = this.chain[this.chain.length - 1];
    const previousBlock = this.chain[this.chain.length - 2];

    if (previousBlock) {
      const timeTaken =
        (latestBlock.timestamp - previousBlock.timestamp) * 1000; // Convert to milliseconds
      if (timeTaken < this.blockTime) {
        this.difficulty++;
      } else if (timeTaken > this.blockTime) {
        this.difficulty--;
      }
    }
  }
}

function constructMerkleTree(inputs) {
  // TODO: Implement Merkle Tree construction if required
}

function simulateChain(blockchain, numTxs, numBlocks) {
  for (let i = 0; i < numBlocks; i++) {
    const numTxsRand = Math.floor(Math.random() * Math.floor(numTxs));
    for (let j = 0; j < numTxsRand; j++) {
      const sender = uuidv4().substr(0, 5);
      const receiver = uuidv4().substr(0, 5);
      blockchain.createTransaction(
        Math.floor(Math.random() * Math.floor(1000)),
        sender,
        receiver
      );
    }
    blockchain.mine();
  }
}

const BChain = new Blockchain();
simulateChain(BChain, 5, 3);

module.exports = Blockchain;

// Uncomment these to run a simulation
console.dir(BChain, { depth: null });
console.log("******** Validity of this blockchain: ", BChain.chainIsValid());
